package main

import (
	"fmt"
)

func t14_1() {

}



func t14_2() {

}

func main() {
	t14_2()
}
